<?php

require_once(__DIR__ . '/../../config.php');
require_login();

$PAGE->set_url(new moodle_url('/local/new_plugin/index.php'));
$PAGE->set_context(\context_system::instance());

define('AJAX_SCRIPT', true);

global $CFG,$PAGE,$OUTPUT,$DB;
$classes = $DB->get_records('local_new_plugin');
$table = new html_table();
$table->id = "local_new_plugin_head";

$table->head[] = 'First Name';
$table->head[] = 'Last Name';
$table->head[] = 'Date of Birth';
$table->head[] = 'Gender';
$table->head[] = 'Mobile no.';
$table->head[] = 'Email Id';
$data = array();

foreach ($classes as $class) {
   $line = array();
   $line[] = ucfirst($class->fname);
   $line[] = $class->lname;
   $line[] = date('d/M/Y', $class->dob);
   $line[] = $class->gender;
   $line[] = $class->mobile;
   $line[] = $class->email;
   $data[] = $line;
}

$table->id = "student_data";
$table->data = $data;
require_once($CFG->libdir.'/csvlib.class.php');
   $matrix = array();
   $filename = 'local_new_plugin_data';
   if (!empty($table->head)) {
       $countcols = count($table->head);
       $keys = array_keys($table->head);
       $lastkey = end($keys);
       foreach ($table->head as $key => $heading) {
          $matrix[0][$key] = str_replace("\n",' ', htmlspecialchars_decode(strip_tags(nl2br($heading))));
       }
   }
   if (!empty($table->data)) {
       foreach ($table->data as $rkey => $row) {
          foreach ($row as $key => $item) {
               $matrix[$rkey + 1][$key] = str_replace("\n",' ', htmlspecialchars_decode(strip_tags(nl2br($item))));
          }
       }
   }
   $csvexport = new csv_export_writer();
   $csvexport->set_filename($filename);
   foreach ($matrix as $ri => $col) {
       $csvexport->add_data($col);
   }
   $csvexport->download_file();
   exit;
