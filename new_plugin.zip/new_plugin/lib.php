<?php

defined('MOODLE_INTERNAL') || die();

use local_new_plugin\form\editform as editform;

function local_new_plugin_output_fragment_editform($args) {
    global $CFG,$PAGE,$DB;

    $args = (object) $args;
    $id = $args->id;
    $oggy = '';
   if ($id) {
        $record = $DB->get_record('local_new_plugin', array('id' => $id));
        $syscontext=context_system::instance();

    }
    $formdata = [];
    if (!empty($args->jsonformdata)) {
        $serialiseddata = json_decode($args->jsonformdata);
        parse_str($serialiseddata, $formdata);
    }

    if(!empty($record) && empty($formdata)){
        $formdata = (array)$record;

    }
    // $data = array();
    $oggy = '';

    $mform = new editform(null, (array)$data, 'post', '', null, true, $formdata);
    $mform->set_data($record);
     if (!empty($args->jsonformdata) && strlen($args->jsonformdata)>2) {
        // If we were passed non-empty form data we want the mform to call validation functions and show errors.
        $mform->is_validated();
    }

    ob_start();
    $mform->display();
    $oggy .= ob_get_contents();
    ob_end_clean();

    return $oggy;
}
