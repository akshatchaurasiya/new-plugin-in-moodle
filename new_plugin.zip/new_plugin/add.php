<?php

require_once(__DIR__ . '/../../config.php');
require_login();
require_once($CFG->dirroot . '/local/new_plugin/classes/form/add.php');

global $DB;

$PAGE->set_url(new moodle_url('/local/new_plugin/add.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Add');
$PAGE->set_heading('Add Details');
$PAGE->navbar->add('Records', new moodle_url('/local/new_plugin/index.php'));



// form block code for display form
$mform = new add();


if ($mform->is_cancelled()) {
    // Go back to index.php page
    redirect($CFG->wwwroot.'/local/new_plugin/index.php', 'You cancelled the form');
}


else if ($fromform = $mform->get_data()) {
  // Insert the data into our database table.
  $recordtoinsert = new stdClass();
  $recordtoinsert->fname = $fromform->fname;
  $recordtoinsert->lname = $fromform->lname;
  $recordtoinsert->dob = $fromform->dob;
  $recordtoinsert->gender = $fromform->gender;
  $recordtoinsert->mobile = $fromform->mobile;
  $recordtoinsert->email = $fromform->email;
  // print_r($recordtoinsert);
  // die;

  $DB->insert_record('local_new_plugin', $recordtoinsert);

  // Go back to index.php page
  redirect($CFG->wwwroot.'/local/new_plugin/index.php', 'Your class successfully saved');

}


echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
