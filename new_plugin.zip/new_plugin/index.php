<?php

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir.'/formslib.php');

require_login();

$PAGE->requires->jquery();
  $PAGE->requires->css(new moodle_url('https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css'));
  $PAGE->requires->js(new moodle_url('https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js'),true);
  $PAGE->requires->js(new moodle_url('https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js'),true);
$PAGE->requires->js_call_amd('local_new_plugin/formAjax','load',array());
$PAGE->requires->js('/local/new_plugin/js/table.js');

global $DB, $PAGE, $local_new_plugin;

$PAGE->set_url(new moodle_url('/local/new_plugin/index.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_heading('New_Plugin');
$PAGE->set_title('New Plugin');
//$PAGE->navbar->add('Class Records', new moodle_url('/local/message/manage.php'));
$PAGE->navbar->add('');


$newplugin = $DB->get_records('local_new_plugin');

// foreach ($newplugin as $result) {
//   $id = $result->id;
//   $result->dob = date('d-M-Y', $result->dob);
//   // $result->visible = $result->status == 1 ? true : false;
// }

echo $OUTPUT->header();

$templatecontext = (object)[
  'newplugin' => array_values($newplugin),

  'add' => new moodle_url('/local/new_plugin/add.php'),
  // 'update' => new moodle_url('/local/new_plugin/update.php'),
  // 'delete' => new moodle_url('/local/new_plugin/delete.php'),
  // 'upload' => new moodle_url('/local/new_plugin/upload.php'),
  'download' => new moodle_url('/local/new_plugin/download.php'),
 ];
 if($is_manager || is_siteadmin()) {
  echo $OUTPUT->render_from_template('local_new_plugin/manage1', $templatecontext);
 }

else {
  echo $OUTPUT->render_from_template('local_new_plugin/manage2', $templatecontext);
}

echo $OUTPUT->footer();
