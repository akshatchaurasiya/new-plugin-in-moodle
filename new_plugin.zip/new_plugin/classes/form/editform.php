<?php
namespace local_new_plugin\form;
require_once($CFG->libdir.'/formslib.php');
use core;
use moodleform;
use context_system;
class editform extends \moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;

          $mform = $this->_form; // Don't forget the underscore!
          $id = $this->_customdata['id'];

         // $mform->addElement('header', 'register', get_string('reg','local_message'));

          $mform->addElement('hidden', 'id');
          $mform->setType('int', PARAM_INT);
          $mform->setDefault('id', $id);

          $mform->addElement('text', 'fname', 'First Name'); // Add elements to your form.
          $mform->addRule('fname', null, 'required');
          $mform->addRule('fname', null, 'lettersonly');
          $mform->setType('fname', PARAM_NOTAGS);                   // Set type of element.
          // $mform->setDefault('fname', 'Please enter your first name');        // Default value.

          $mform->addElement('text', 'lname', 'Last Name'); // Add elements to your form.
          $mform->addRule('lname', null, 'required');
          $mform->addRule('lname', null, 'lettersonly');
          $mform->setType('lname', PARAM_NOTAGS);                   // Set type of element.
          // $mform->setDefault('lname', 'Please enter your last name');        // Default value.

          $mform->addElement('date_selector', 'dob', 'Date of Birth'); // Add elements to your form.
          $mform->addRule('dob', null, 'required');
          $mform->setType('dob', PARAM_NOTAGS);                   // Set type of element.

          $radioarray=array();
          $radioarray[] = $mform->createElement('radio', 'gender', '', get_string('male', 'local_new_plugin'), 'Male');
          $radioarray[] = $mform->createElement('radio', 'gender', '', get_string('female', 'local_new_plugin'), 'Female');
          $mform->addGroup($radioarray, 'radio', 'Gender', array(' '), false);
          $mform->addRule('radio', null, 'required');


          $mform->addElement('text', 'mobile', 'Mobile No.','maxlength="10", pattern="[6-9][0-9]{9}"', $val); // Add elements to your form.
          $mform->addRule('mobile', null, 'required');
          $mform->addRule('mobile', null, 'numeric');
          $mform->setType('mobile', PARAM_NOTAGS);                   // Set type of element.
          //$mform->setDefault('mobile', 'Please enter your mobile no');        // Default value.

          $mform->addElement('text', 'email', 'Email', 'pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"'); // Add elements to your form.
          $mform->addRule('email', null, 'required');
          $mform->setType('email', PARAM_NOTAGS);                   // Set type of element.
          //$mform->setDefault('lname', 'Please enter your last name');        // Default value.

    }
    //Custom validation should be added here
    function validation($data, $files) {
      $errors = parent::validation($data, $files);
      global $DB;

      // Check open and close times are consistent.
      // if($data['startdate'] != 0 && $data['enddate'] != 0 && $data['enddate'] <= $data['startdate']) {
      //   $errors['enddate'] = get_string('closebeforeopen', 'local_message');
      // }

      if($data['dob'] > time() - 60 * 60 * 24 * 365 * 18){
        $errors['dob'] = get_string('cdob', 'local_new_plugin');
      }



      // start duplicate validation

      // Add field validation check for duplicate Entry.
      if ($dbdent = $DB->get_record('local_new_plugin', array('mobile'=> $data['mobile']), '*', IGNORE_MULTIPLE)){

          if (empty($data['id']) || $dbdent->id != $data['id']) {

              $errors['mobile'] = get_string('duplicatem', 'local_new_plugin');
          }
      }


      if ($dbdent = $DB->get_record('local_new_plugin', array('email'=> $data['email']), '*', IGNORE_MULTIPLE)){

          if (empty($data['id']) || $dbdent->id != $data['id']) {

              $errors['email'] = get_string('duplicatee', 'local_new_plugin');
          }
      }
      if(count($errors) == 0) {
        return true;
      } else {
        return $errors;
      }
      return $errors;
    }
}
