<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/externallib.php');
require_once($CFG->libdir.'/filelib.php');


 use local_new_plugin\form\editform as editform;

class local_new_plugin_external extends external_api {

     public static function submit_register_parameters() {

          return new external_function_parameters(
            array(
                'contextid' => new external_value(PARAM_INT, 'The context id for the system',0),
                'id' => new external_value(PARAM_INT,'Class id',0),
                'jsonformdata' => new external_value(PARAM_RAW, 'The data from the create class form, encoded as a json array')
            )
        );
    }
    public static  function submit_register($contextid, $id, $jsonformdata) {

        global $CFG,$DB;



        $params=self::validate_parameters(

            self::submit_register_parameters(),
            array('contextid'=>$contextid,'id'=>$id,'jsonformdata'=>$jsonformdata)
        );
        $context=context::instance_by_id($params['contextid'],'MUST_EXIST');

        self::validate_context($context);

         $serialiseddata=json_decode($params['jsonformdata']);

         $data=array();

         parse_str($serialiseddata, $data);

        $warnings = array();


         $mform = new editform(null, array('id'=>$id), 'post', '', null, true, $data);

        $validateddata = $mform->get_data();

        // var_dump($validateddata);
        // exit;

        if ($validateddata) {

            if($validateddata->id > 0) {

                $updaterec = new \stdClass();
                $updaterec->id        = $validateddata->id;
                $updaterec->fname     = $validateddata->fname;
                $updaterec->lname     = $validateddata->lname;
                $updaterec->dob       = $validateddata->dob;
                $updaterec->gender    = $validateddata->gender;
                $updaterec->mobile    = $validateddata->mobile;
                $updaterec->email     = $validateddata->email;

                $courseupdaterecord = $DB->update_record('local_new_plugin', $updaterec);

            } else  {

               $createrec = new \stdClass();
               $createrec->fname        = $validateddata->fname;
               $createrec->lname        = $validateddata->lname;
               $createrec->dob          = $validateddata->dob;
               $createrec->gender       = $validateddata->gender;
               $createrec->mobile       = $validateddata->mobile;
               $createrec->email        = $validateddata->email;
               // print_r($createrec);
               // die;
               $insertrecord = $DB->insert_record('local_new_plugin', $createrec);

            }
            } else {
            // Generate a warning.
           throw new moodle_exception('Error in submission');
        }
        $return = array(
            'id' => $id,
            'contextid' => $contextid,
        );

        return $return;
        }

    public static function submit_register_returns() {

         return new external_single_structure(array(
            'id' => new external_value(PARAM_INT, ' id'),
            'contextid' => new external_value(PARAM_INT, 'The context id for the system',0),

        ));
    }
    public static function deleteclass_parameters() {
        return new external_function_parameters(
            array(
                'id'  => new external_value(PARAM_INT, 'id',0),
                // 'classname'  => new external_value(PARAM_INT, 'classname',0),
            )
        );
    }
    public static function deleteclass($id) {
        global $DB;

        $params = self::validate_parameters (

               self::deleteclass_parameters(),array('id'=>$id)
               // self::deleteclass_parameters(),array('classname'=>$classname)
       );
        $context = context_system::instance();
        self::validate_context($context);
        if($id) {
            $delete = $DB->delete_records('local_new_plugin',array('id'=>$id));
        } else {
            throw new moodle_exception('Error');
        }
     }
     public static function deleteclass_returns(){

        return null;
     }


}
