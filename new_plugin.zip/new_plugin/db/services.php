<?php
 defined('MOODLE_INTERNAL') || die();
$functions = array(

	 'local_new_plugin_deleteclass' => array( // local_PLUGINNAME_FUNCTIONNAME is the name of the web service function that the client will call.
                'classname'   => 'local_new_plugin_external', // create this class in componentdir/classes/external
                'classpath'   => 'local/new_plugin/classes/external.php',
                'methodname'  => 'deleteclass', // implement this function into the above class
                'description' => 'This documentation will be displayed in the generated API documentationAdministration > Plugins > Webservices > API documentation)',
                'type'        => 'write', // the value is 'write' if your function does any database change, otherwise it is 'read'.
                'ajax'        => true, // true/false if you allow this web service function to be callable via ajax

        ),

        'local_new_plugin_submit_register' => array( // local_PLUGINNAME_FUNCTIONNAME is the name of the web service function that the client will call.
                  'classname'   => 'local_new_plugin_external', // create this class in componentdir/classes/external
                  'classpath'   => 'local/new_plugin/classes/external.php',
                  'methodname'  => 'submit_register', // implement this function into the above class
                  'description' => 'This documentation will be displayed in the generated API documentationAdministration > Plugins > Webservices > API documentation)',
                  'type'        => 'write', // the value is 'write' if your function does any database change, otherwise it is 'read'.
                  'ajax'        => true, // true/false if you allow this web service function to be callable via ajax

          ),
);
