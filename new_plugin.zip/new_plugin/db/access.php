<?php
 defined('MOODLE_INTERNAL') || die();
$capabilities = [
    'local/new_plugin:viewcontent' => [
        'riskbitmask' => RISK_SPAM,
        'captype' => 'read',
        'contextlevel' => CONTEXT_USER,
        'archetypes' => [
            'manager' => CAP_ALLOW,
        ],
        'local/new_plugin:viewcontent' => [
          'riskbitmask' => RISK_SPAM,
          'captype' => 'write',
          'contextlevel' => CONTEXT_SYSTEM,
          'archetypes' => [
              'manager' => CAP_ALLOW,
            ],
        ],
    ],
 ];
