<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_new_plugin';
$plugin->version = 202206090008;
$plugin->requires = 2016052300;
$plugin->release   = '1G v1.7';
$plugin->maturity  = MATURITY_STABLE;
